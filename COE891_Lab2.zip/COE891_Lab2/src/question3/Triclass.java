package question3;

public class Triclass {
    public static String classify(int x, int y, int z) {
        if (x <= 0 || y <= 0 || z <= 0 || x > 10 || y > 10 || z > 10) {
            return "invalid";
        }
        if (x >= y + z || y >= x + z || z >= x + y) {
            return "invalid";
        }
        if (x == y && y == z) {
            return "equilateral";
        }
        if (x == y || y == z || x == z) {
            return "isosceles";
        }
        return "scalene";
    }
}
