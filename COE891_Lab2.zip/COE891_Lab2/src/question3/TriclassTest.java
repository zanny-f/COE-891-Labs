package question3;

import org.junit.Test;
import org.junit.BeforeClass;
import org.junit.AfterClass;
import static org.junit.Assert.assertEquals;

public class TriclassTest {

    @BeforeClass
    public static void startTests() {
        System.out.println("Testing started");
    }

    @AfterClass
    public static void finishTests() {
        System.out.println("Testing finished");
    }

    @Test
    public void testEquilateral() {
        System.out.println("#Test_Equilateral - started");
        assertEquals("equilateral", Triclass.classify(5, 5, 5));
        System.out.println("#Test_Equilateral - finished");
    }

    @Test
    public void testIsosceles() {
        System.out.println("#Test_Isosceles - started");
        assertEquals("isosceles", Triclass.classify(5, 5, 8));
        System.out.println("#Test_Isosceles - finished");
    }

    @Test
    public void testScalene() {
        System.out.println("#Test_Scalene - started");
        assertEquals("scalene", Triclass.classify(3, 4, 5));
        System.out.println("#Test_Scalene - finished");
    }

    @Test
    public void testInvalidByInequality() {
        System.out.println("#Test_InvalidByInequality - started");
        assertEquals("invalid", Triclass.classify(5, 9, 3));
        System.out.println("#Test_InvalidByInequality - finished");
    }

    @Test
    public void testInvalidBySideLength() {
        System.out.println("#Test_InvalidBySideLength - started");
        assertEquals("invalid", Triclass.classify(0, 5, 5));
        System.out.println("#Test_InvalidBySideLength - finished");
    }
}
