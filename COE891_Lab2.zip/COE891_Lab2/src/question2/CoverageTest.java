package question2;

import org.junit.Test;
import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.AfterClass;
import static org.junit.Assert.assertEquals;

public class CoverageTest {

    // BeforeClass is executed once before any of the test methods in the class.
    @BeforeClass
    public static void globalSetup() {
        System.out.println("Testing started");
    }

    // AfterClass is executed once after all the test methods in the class.
    @AfterClass
    public static void globalTeardown() {
        System.out.println("Testing finished");
    }

    // Before is executed before each test method.
    @Before
    public void setUp() {
        System.out.println("Test started");
    }

    // After is executed after each test method.
    @After
    public void tearDown() {
        System.out.println("Test finished");
    }

    // The method to be tested
    public int func(int a, int b) {
        if (b > a) {
            return b - a;
        } else if (a > b) {
            return a - b;
        } else {
            return 0;
        }
    }

    // JUnit test cases
    @Test
    public void testFuncBGreaterThanA() {
        System.out.println("#Test_BGreaterThanA - started");
        assertEquals("b > a should return b - a", 1, func(2, 3));
        System.out.println("#Test_BGreaterThanA - finished");
    }

    @Test
    public void testFuncAGreaterThanB() {
        System.out.println("#Test_AGreaterThanB - started");
        assertEquals("a > b should return a - b", 1, func(3, 2));
        System.out.println("#Test_AGreaterThanB - finished");
    }

    @Test
    public void testFuncAEqualsB() {
        System.out.println("#Test_AEqualsB - started");
        assertEquals("a == b should return 0", 0, func(1, 1));
        System.out.println("#Test_AEqualsB - finished");
    }
}
