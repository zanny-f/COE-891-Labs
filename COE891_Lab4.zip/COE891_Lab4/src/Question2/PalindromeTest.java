package Question2;

import static org.junit.Assert.*;
import org.junit.Test;

public class PalindromeTest {

    @Test(expected = NullPointerException.class)
    public void testNullInput() {
        // This will cover the path 1-2-4 and expect an exception
        String s = null;
        boolean result = Palindrome.isPalindrome(s);
    }

    @Test
    public void testEmptyString() {
        // This will cover the path 1-2-3-5-8-9 with an empty string
        String s = "";
        boolean result = Palindrome.isPalindrome(s);
        assertTrue("Empty string is a palindrome", result);
    }

    @Test
    public void testSingleCharacterString() {
        // This will also cover the path 1-2-3-5-8-9 with a single character string
        String s = "a";
        boolean result = Palindrome.isPalindrome(s);
        assertTrue("Single character string is a palindrome", result);
    }

    @Test
    public void testPalindromeEvenLength() {
        // This will cover the path 1-2-3-5-6-7-8-9 with an even length palindrome
        String s = "abba";
        boolean result = Palindrome.isPalindrome(s);
        assertTrue("Even length palindrome", result);
    }

    @Test
    public void testPalindromeOddLength() {
        // This will cover the path 1-2-3-5-6-7-8-9 with an odd length palindrome
        String s = "racecar";
        boolean result = Palindrome.isPalindrome(s);
        assertTrue("Odd length palindrome", result);
    }

    @Test
    public void testNotPalindrome() {
        // This will cover the path 1-2-3-5-6-9 with a non-palindrome
        String s = "hello";
        boolean result = Palindrome.isPalindrome(s);
        assertFalse("Not a palindrome", result);
    }
}
