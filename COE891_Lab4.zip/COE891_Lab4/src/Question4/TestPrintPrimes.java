package Question4;

import static org.junit.Assert.*;
import org.junit.Test;
import static org.junit.Assert.assertArrayEquals;

public class TestPrintPrimes {
	

    @Test
    public void testOnePrime() {
        int[] expected = new int[]{2};
        assertArrayEquals("Array should contain just the first prime", expected, PrintPrimes.getPrimes(1));
    }

    @Test
    public void testTwoPrimes() {
        int[] expected = new int[]{2, 3};
        assertArrayEquals("Array should contain the first two primes", expected, PrintPrimes.getPrimes(2));
    }

    @Test
    public void testThreePrimes() {
        int[] expected = new int[]{2, 3, 5};
        assertArrayEquals("Array should contain the first three primes", expected, PrintPrimes.getPrimes(3));
    }

    @Test
    public void testFourPrimes() {
        int[] expected = new int[]{2, 3, 5, 7};
        assertArrayEquals("Array should contain the first four primes", expected, PrintPrimes.getPrimes(4));
    }
}

