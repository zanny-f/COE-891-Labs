package Question5;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class GoogleSearchTestPart2 {

	public static String baseURL = "https://www.google.com/";
	static String driverURL = "C:\\chromedriver.exe";
	public static WebDriver driver;
	
	@BeforeSuite
	public void openBrowser() {
		System.out.println("Launching Chrome");
        System.setProperty("Webdriver.chrome.driver", driverURL);
        driver = new ChromeDriver(); 
		driver.get(baseURL);
		Assert.assertEquals("Google", driver.getTitle());
		System.out.println("Opened Google");
	}
//	@Test
//	public void launchGoogle() {
//
//	}
	@Test
	public void performSearchAndClick1stLink() throws InterruptedException {
		WebElement tb = driver.findElement(By.id("APjFqb"));
		tb.sendKeys("Facebook");
		System.out.println("Typed Facebook");
		Thread.sleep(1000);
		WebElement btn = driver.findElement(By.name("btnK"));
		btn.click();
		System.out.println("Searched Facebook");
//		WebElement search = driver.findElement(By.xpath("//a[@href='https://www.facebook.com/']"));
//		search.click();
		Thread.sleep(1000);
	}
	
	@Test (dependsOnMethods = { "performSearchAndClick1stLink" })
	public void FacebookPageTitleVerification() throws InterruptedException {
//		String title = driver.getTitle();
		System.out.println("Title is: "+driver.getTitle());
		Assert.assertTrue(driver.getTitle().contains("Facebook - Google Search"));
		Thread.sleep(3000);
	}
	@AfterSuite
	public void driverExit() {
		driver.close();
	}
}

