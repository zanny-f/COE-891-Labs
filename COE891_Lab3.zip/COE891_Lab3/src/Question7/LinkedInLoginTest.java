package Question7;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class LinkedInLoginTest {
    private WebDriver driver;
    private final String linkedInUrl = "https://www.linkedin.com/login";
    private final String expectedUrlAfterLogin = "https://www.linkedin.com/feed/";
    private final String username = ""; // Replace with your username left empty for the reason of submitting
    private final String password = ""; // Replace with your password left empty for the reason of submitting 

    @BeforeTest
    public void setUp() {
        System.setProperty("webdriver.chrome.driver", "C:\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.get(linkedInUrl);
    }

    @Test
    public void testLinkedInLogin() throws InterruptedException {
        // Find the username input field and fill it with the username
        WebElement usernameField = driver.findElement(By.id("username"));
        usernameField.sendKeys(username);

        // Find the password input field and fill it with the password
        WebElement passwordField = driver.findElement(By.id("password"));
        passwordField.sendKeys(password);

        // Find the sign-in button and click it
        WebElement signInButton = driver.findElement(By.xpath("//button[@type='submit']"));
        signInButton.click();

        // Wait for redirection to the feed page after login
        Thread.sleep(5000); // It's better to use explicit waits

        // Verify the URL to ensure login was successful
        String currentUrl = driver.getCurrentUrl();
        Assert.assertEquals(currentUrl, expectedUrlAfterLogin, "Login was not successful or the URL did not match.");
        
        // Print a suitable message
        if(currentUrl.equals(expectedUrlAfterLogin)) {
            System.out.println("Login successful.");
        } else {
            System.out.println("Login failed.");
        }
    }

    @AfterTest
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
    
    public static void main(String[] args) throws InterruptedException {
        LinkedInLoginTest test = new LinkedInLoginTest();
        test.setUp();
        try {
            test.testLinkedInLogin();
        } finally {
            test.tearDown();
        }
    }
}
