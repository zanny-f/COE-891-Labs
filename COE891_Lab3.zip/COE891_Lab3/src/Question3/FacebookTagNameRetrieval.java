package Question3;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class FacebookTagNameRetrieval {
    public static void main(String[] args) {
        // Set the path to the chromedriver executable
        System.setProperty("webdriver.chrome.driver", "C:\\chromedriver.exe");

        // Initialize the ChromeDriver
        WebDriver driver = new ChromeDriver();

        try {
            // Navigate to Facebook
            driver.get("http://www.facebook.com");

            // Find the email text field by its name attribute
            WebElement emailTextField = driver.findElement(By.name("email"));

            // Retrieve the tag name of the email text field
            String tagName = emailTextField.getTagName();

            // Print the tag name to the output
            System.out.println("The tag name of the email text field is: " + tagName);
        } finally {
            // Close the browser
            driver.quit();
        }
    }
}
