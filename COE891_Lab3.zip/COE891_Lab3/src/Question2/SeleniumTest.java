package Question2;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class SeleniumTest {
    private WebDriver driver;

    @BeforeTest
    public void setUp() {
        // Set the path to the chromedriver executable
        System.setProperty("webdriver.chrome.driver", "C:\\chromedriver.exe");

        // Initialize the ChromeDriver
        driver = new ChromeDriver();
    }

    @Test
    public void testWebsiteTitle() {
        // Navigate to the website
        driver.get("http://demo.guru99.com/test/newtours/");

        // Retrieve the title of the web page
        String title = driver.getTitle();
        System.out.println("The title of the page is: " + title);

        // Assert that the title is equal to "Welcome: Mercury Tours"
        Assert.assertEquals(title, "Welcome: Mercury Tours");
    }

    @AfterTest
    public void tearDown() {
        // Close the browser
        driver.quit();
    }

    public static void main(String[] args) {
        SeleniumTest test = new SeleniumTest();
        test.setUp();
        test.testWebsiteTitle();
        test.tearDown();
    }
}
