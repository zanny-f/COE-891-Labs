package Question6;
//check
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class ParallelSessionTest {
    
    @Test
    public void executeSessionOne() {
        WebDriver driver = setupDriver();
        driver.get("http://demo.guru99.com/V4/");
        WebElement userId = driver.findElement(By.name("uid"));
        userId.sendKeys("Driver 1");
//        driver.quit();
    }

    @Test
    public void executeSessionTwo() {
        WebDriver driver = setupDriver();
        driver.get("http://demo.guru99.com/V4/");
        WebElement userId = driver.findElement(By.name("uid"));
        userId.sendKeys("Driver 2");
//        driver.quit();
    }

    @Test
    public void executeSessionThree() {
        WebDriver driver = setupDriver();
        driver.get("http://demo.guru99.com/V4/");
        WebElement userId = driver.findElement(By.name("uid"));
        userId.sendKeys("Driver 3");
//        driver.quit();
    }

    private WebDriver setupDriver() {
        System.setProperty("webdriver.chrome.driver", "C:\\chromedriver.exe");
        return new ChromeDriver();
    }
}

