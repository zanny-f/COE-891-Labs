package Question4;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class TodoAppTest {
    private WebDriver driver;

    @BeforeTest
    public void setUp() {
        // Set the path to the chromedriver executable
        System.setProperty("webdriver.chrome.driver", "C:\\chromedriver.exe");

        // Initialize the ChromeDriver
        driver = new ChromeDriver();
    }

    @Test
    public void testTodoApp() {
        // Navigate to the sample to-do app
        driver.get("https://lambdatest.github.io/sample-todo-app/");

        // Find and check the "Second Item"
        WebElement secondItem = driver.findElement(By.name("li2"));
        secondItem.click();
        Assert.assertTrue(secondItem.isSelected(), "Second Item should be selected");

        // Find and check the "Fourth Item"
        WebElement fourthItem = driver.findElement(By.name("li4"));
        fourthItem.click();
        Assert.assertTrue(fourthItem.isSelected(), "Fourth Item should be selected");

        // Find the input field, clear it, add a new item and submit it
        WebElement addItemInput = driver.findElement(By.id("sampletodotext"));
        addItemInput.clear();
        addItemInput.sendKeys("Farzaan");
        driver.findElement(By.id("addbutton")).click();

        // Verify the new item was added
        WebElement newItem = driver.findElement(By.xpath("//li[contains(text(),'Farzaan')]"));
        Assert.assertTrue(newItem.isDisplayed(), "New item should be displayed in the list");
    }

    @AfterTest
    public void tearDown() {
        // Close the browser
        driver.quit();
    }

    public static void main(String[] args) {
        TodoAppTest test = new TodoAppTest();
        test.setUp();
        test.testTodoApp();
        test.tearDown();
    }
}
