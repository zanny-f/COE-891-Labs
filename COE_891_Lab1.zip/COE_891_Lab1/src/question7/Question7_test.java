package question7;

import static org.junit.Assert.*;
import static org.junit.Assume.assumeFalse;
import static org.junit.Assume.assumeNotNull;
import static org.junit.Assume.assumeTrue;
import org.junit.experimental.theories.DataPoints;
import org.junit.experimental.theories.Theories;
import org.junit.experimental.theories.Theory;
import org.junit.runner.RunWith;

@RunWith(Theories.class)
public class Question7_test {
	@DataPoints
	public static int [] val= new int[] {1, 2,307, 500567};
	@DataPoints
	public static int [] newVal= new int[] {0, -1, -10, -1234, 1, 10, 6789};
	@DataPoints
	public static int [] updatedVal= new int[] {0, -1, -10, -1234, 1, 10, 6789, Integer.MAX_VALUE, Integer.MIN_VALUE};

	@Theory
	public void testingValues(int a, int b) {
		assumeNotNull(a, b);
		assumeTrue(a>0&&b>0);
		System.out.println("Value for a= "+a+" Value for b= "+b);
		
		//If integer a or b is the Max interger it will skip it
		assumeFalse(a == Integer.MAX_VALUE || b == Integer.MAX_VALUE);
		
		assertTrue(a+b >a);
		assertTrue(a+b>b);
	}
	
	@Theory
	public void testCombined(int a, int b){
		assumeNotNull(a, b);
		assumeTrue(a>0 && b>0);
		assumeTrue(a+b == b+a);	
	}
}
