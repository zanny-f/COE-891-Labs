package question7;
import org.junit.experimental.theories.DataPoints;
import org.junit.experimental.theories.Theory;
import org.junit.runner.RunWith;
import org.junit.experimental.theories.Theories;
import static org.junit.Assert.*;
import static org.junit.Assume.*;

@RunWith(Theories.class)
public class MathTheoryTest {

    // Data points for various test cases
    @DataPoints
    public static int[] values = new int[] {1, 2, 307, 400567};
    @DataPoints
    public static int[] newValues = new int[] {0, -1, -10, -1234, 1, 10, 6789};
    @DataPoints
    public static int[] extendedValues = new int[] {0, -1, -10, -1234, 1, 10, 6789, Integer.MAX_VALUE, Integer.MIN_VALUE};

    // Tests the commutative property of addition
    @Theory
    public void testCommutativeProperty(int a, int b) {
        System.out.println("Testing commutative property with values: a=" + a + ", b=" + b);
        assertEquals(a + b, b + a);
    }

    // Tests the commutative property of addition with newValues
    @Theory
    public void testCommutativePropertyWithNewValues(int a, int b) {
        System.out.println("Testing commutative property with new values: a=" + a + ", b=" + b);
        assertEquals(a + b, b + a);
    }

    // Tests if the sum of two positive numbers is greater than each of the numbers
    @Theory
    public void testAdditionGreaterWithExtendedValues(int a, int b) {
        System.out.println("Testing addition greater with extended values: a=" + a + ", b=" + b);
        assumeTrue(a > 0 && b > 0); // Only for positive numbers
        assumeTrue(!willOverflow(a, b)); // Skip if overflow
        assertTrue("Failed at a=" + a + ", b=" + b, a + b > a);
        assertTrue("Failed at a=" + a + ", b=" + b, a + b > b);
    }

    // Tests the commutative property of addition with extendedValues
    @Theory
    public void testCommutativePropertyWithExtendedValues(int a, int b) {
        System.out.println("Testing commutative property with extended values: a=" + a + ", b=" + b);
        assertEquals(a + b, b + a);
    }

    // Helper method to check for integer overflow
    private boolean willOverflow(int a, int b) {
        System.out.println("Checking for overflow: a=" + a + ", b=" + b);
        if (a > 0 && b > 0 && Integer.MAX_VALUE - b < a) {
            return true; // Overflow in positive addition
        }
        if (a < 0 && b < 0 && Integer.MIN_VALUE - b > a) {
            return true; // Overflow in negative addition
        }
        return false;
    }
}
