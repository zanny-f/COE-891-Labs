package question1;

public class ArrayMult {
    public int[] mult(int[] array1, int[] array2) {
        // Determine the shorter and longer arrays
        int[] minArray = array1.length <= array2.length ? array1 : array2;
        int[] longArray = array1.length > array2.length ? array1 : array2;
        int[] outArray = new int[longArray.length];

        // Perform point-wise multiplication for indices that exist in both arrays
        for (int i = 0; i < minArray.length; i++) {
            outArray[i] = array1[i] * array2[i];
        }

        // Copy the remaining elements from the longer array
        for (int j = minArray.length; j < longArray.length; j++) {
            outArray[j] = longArray[j];
        }

        return outArray;
    }
}