package question1;

import static org.junit.Assert.assertArrayEquals;
import org.junit.Test;

public class ArrayMultTest {

    /**
     * Test multiplication of two arrays with equal lengths.
     * Both arrays have the same length and contain the elements {1, 2, 3}.
     * Expected result is element-wise multiplication: {1*1, 2*2, 3*3} = {1, 4, 9}.
     */
    @Test
    public void testMultEqualLengthArrays() {
        ArrayMult am = new ArrayMult();
        System.out.println("Testing with arrays of equal length");
        assertArrayEquals(new int[]{1, 4, 9}, am.mult(new int[]{1, 2, 3}, new int[]{1, 2, 3}));
    }

    /**
     * Test multiplication when the first array is longer.
     * The first array is longer than the second. Expected behavior is that
     * the multiplication will only happen for the length of the shorter array.
     * Expected result: {1*1, 2*2, 3} = {1, 4, 3}.
     */
    @Test
    public void testMultFirstArrayLonger() {
        ArrayMult am = new ArrayMult();
        System.out.println("Testing with the first array longer than the second");
        assertArrayEquals(new int[]{1, 4, 3}, am.mult(new int[]{1, 2, 3}, new int[]{1, 2}));
    }

    /**
     * Test multiplication when the second array is longer.
     * The second array is longer than the first. Expected behavior is that
     * the multiplication will include all elements of the longer array.
     * Expected result: {1*1, 2*2, 5, 6} = {1, 4, 5, 6}.
     */
    @Test
    public void testMultSecondArrayLonger() {
        ArrayMult am = new ArrayMult();
        System.out.println("Testing with the second array longer than the first");
        assertArrayEquals(new int[]{1, 4, 5, 6}, am.mult(new int[]{1, 2}, new int[]{1, 2, 5, 6}));
    }
    
    // Additional tests can be added to cover more cases such as empty arrays, large numbers, etc.
}
