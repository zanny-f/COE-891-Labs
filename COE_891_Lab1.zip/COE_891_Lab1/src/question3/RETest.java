package question3;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

public class RETest {
    private RE phoneValidator;

    // Set up method to initialize the phoneValidator object before each test
    @Before
    public void setUp() {
        phoneValidator = new RE();
        System.out.println("Setting up phoneValidator for the tests.");
    }

    // Test to check if a valid phone number with spaces is correctly validated
    @Test
    public void testValidPhoneNumberWithSpaces() {
        System.out.println("Testing valid phone number with spaces: (123) 456-7890");
        assertTrue("Valid phone number with spaces should pass.", phoneValidator.checkPhoneNumber("(123) 456-7890"));
    }

    // Test to check if a valid phone number without spaces is correctly validated
    @Test
    public void testValidPhoneNumberWithoutSpaces() {
        System.out.println("Testing valid phone number without spaces: (123)456-7890");
        assertTrue("Valid phone number without spaces should pass.", phoneValidator.checkPhoneNumber("(123)456-7890"));
    }

    // Test to check if a phone number without a dash is correctly invalidated
    @Test
    public void testInvalidPhoneNumberNoDash() {
        System.out.println("Testing invalid phone number with no dash: (123) 456 7890");
        assertFalse("Phone number without dash should fail.", phoneValidator.checkPhoneNumber("(123) 456 7890"));
    }

    // Test to check if a phone number with extra characters is correctly invalidated
    @Test
    public void testInvalidPhoneNumberExtraCharacters() {
        System.out.println("Testing invalid phone number with extra characters: (123) 456-7890 ext");
        assertFalse("Phone number with extra characters should fail.", phoneValidator.checkPhoneNumber("(123) 456-7890 ext"));
    }

    // Test to check if a phone number with letters is correctly invalidated
    @Test
    public void testInvalidPhoneNumberLetters() {
        System.out.println("Testing invalid phone number with letters: (abc) def-ghij");
        assertFalse("Phone number with letters should fail.", phoneValidator.checkPhoneNumber("(abc) def-ghij"));
    }

}
