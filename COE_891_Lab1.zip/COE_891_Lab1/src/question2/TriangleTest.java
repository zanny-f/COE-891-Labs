package question2;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;


//TriangleTest class
public class TriangleTest {
    // Declaring Triangle objects for testing
    Triangle t1, t2, t3;

    // The @Before annotation indicates that this method will be executed before each test.
    // It's used for setting up the test environment.
    @Before
    public void setUp() {
        // Initializing Triangle objects with different sets of sides
        t1 = new Triangle(3, 4, 5);
        t2 = new Triangle(5, 4, 3);
        t3 = new Triangle(8, 5, 5);

        System.out.println("Set up complete with three different triangles for testing.");
    }

    // Test to check the area calculation for the first triangle
    @Test
    public void testCalculateAreaT1() {
        System.out.println("Testing area calculation for Triangle t1. Expected Value= 6.0. Actual Value= "+ t1.calculateArea());
        assertEquals(6.0, t1.calculateArea(), 0.001);
    }

    // Test to check the area calculation for the second triangle
    @Test
    public void testCalculateAreaT2() {
        System.out.println("Testing area calculation for Triangle t2. Expected Value= 6.0. Actual Value= "+ t2.calculateArea());
        assertEquals(6.0, t2.calculateArea(), 0.001);
    }

    // Test to check the area calculation for the third triangle
    @Test
    public void testCalculateAreaT3() {
        System.out.println("Testing area calculation for Triangle t3 . Expected Value= 12.0. Actual Value= "+ t3.calculateArea());
        assertEquals(12.0, t3.calculateArea(), 0.001);
    }

    // Test to check if an IllegalArgumentException is thrown for invalid triangle dimensions
    @Test(expected = IllegalArgumentException.class)
    public void testInvalidTriangle() {
        System.out.println("Testing creation of an invalid triangle");
        new Triangle(3, -4, 100);
    }

    // Test to verify that the sum of any two sides of a triangle must be greater than the third side
    @Test
    public void testTriangleInequality() {
        System.out.println("Testing triangle inequality validation");
        boolean isValid = Triangle.validateSides(3, 4, 5);
        assertTrue(isValid);
    }
}
