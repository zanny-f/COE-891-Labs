package question2;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;
    
    // Triangle class
    public class Triangle {
        private int side1, side2, side3;

        public Triangle(int side1, int side2, int side3) {
            if (!validateSides(side1, side2, side3)) {
                throw new IllegalArgumentException("The sides do not form a valid triangle.");
            }
            this.side1 = side1;
            this.side2 = side2;
            this.side3 = side3;
        }

        public static boolean validateSides(int a, int b, int c) {
            return (a + b > c) && (a + c > b) && (b + c > a);
        }

        public double calculateArea() {
            double s = (side1 + side2 + side3) / 2.0;
            return Math.sqrt(s * (s - side1) * (s - side2) * (s - side3));
        }
        }