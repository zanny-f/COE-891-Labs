package question8;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.experimental.theories.DataPoint;
import org.junit.experimental.theories.Theories;
import org.junit.experimental.theories.Theory;
import org.junit.runner.RunWith;

import question6.PrimeNumberChecker;
import static org.junit.Assert.assertEquals;

@RunWith(Theories.class)
public class PrimeNumberCheckerTheoryTest {

    // DataPoint for the first test case: Testing if 2 is prime
    @DataPoint public static Object[] CASE1 = {2, true};

    // DataPoint for the second test case: Testing if 6 is prime
    @DataPoint public static Object[] CASE2 = {6, false};

    // DataPoint for the third test case: Testing if 19 is prime
    @DataPoint public static Object[] CASE3 = {19, true};
    // ... Other cases here ...

    /**
     * Theory to test the PrimeNumberChecker.
     * Each test case array contains a number and the expected result
     * indicating whether the number is prime or not.
     *
     * @param testCase An array containing a number and its expected prime status.
     */
    @Theory
    public void testPrimeNumberChecker(Object[] testCase) {
        // Extract the number and its expected prime status from the test case
        int number = (Integer) testCase[0];
        boolean expectedPrimeStatus = (Boolean) testCase[1];

        // Print the test case being checked
        System.out.println("Testing if " + number + " is prime. Expected result: " + expectedPrimeStatus);

        // Assert that the actual prime status matches the expected prime status
        assertEquals("Error in test case for number: " + number, 
                     expectedPrimeStatus, PrimeNumberChecker.isPrime(number));
    }
}
