package question8;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.experimental.theories.DataPoint;
import org.junit.experimental.theories.Theories;
import org.junit.experimental.theories.Theory;
import org.junit.runner.RunWith;

import question5.Fibonacci;
import static org.junit.Assert.assertEquals;

@RunWith(Theories.class)
public class FibonacciTheoryTest {

    // DataPoint for the base case: Fibonacci number at index 0
    @DataPoint public static Object[] CASE1 = {0, 0};

    // DataPoint for the first Fibonacci number
    @DataPoint public static Object[] CASE2 = {1, 1};

    // DataPoint for the second Fibonacci number
    @DataPoint public static Object[] CASE3 = {2, 1};

    // ... Other cases here ...

    /**
     * Theory to test the Fibonacci sequence.
     * This method will be called with each DataPoint defined above,
     * checking if the Fibonacci number computed for a given index matches the expected value.
     *
     * @param testCase An array with two elements, 
     *                 where the first element is the index (n) and 
     *                 the second element is the expected Fibonacci number at index n.
     */
    @Theory
    public void testFibonacci(Object[] testCase) {
        // Extract the index and the expected Fibonacci number from the test case
        int index = (Integer) testCase[0];
        int expectedFibonacciNumber = (Integer) testCase[1];

        // Print the details of the test case
        System.out.println("Testing Fibonacci.compute for index: " + index + 
                           " | Expected value: " + expectedFibonacciNumber);

        // Perform the test: Check if the actual Fibonacci number at the given index matches the expected value
        assertEquals(expectedFibonacciNumber, Fibonacci.compute(index));
    }
}
