package question4;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

import question2.TriangleTest;
import question3.RETest;

@RunWith(Suite.class)
@Suite.SuiteClasses({
    RETest.class,
    TriangleTest.class
})
public class AllTestsSuite {
    // This class remains empty, it is used only as a holder for the above annotations
}