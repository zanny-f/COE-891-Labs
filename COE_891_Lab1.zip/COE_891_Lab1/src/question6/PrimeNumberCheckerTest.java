package question6;

import static org.junit.Assert.*;

import org.junit.Test;

import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.Test;
import static org.junit.Assert.assertEquals;
import java.util.Arrays;
import java.util.Collection;

//@RunWith(Parameterized.class)
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.junit.runners.Parameterized;
//import java.util.Arrays;
//import java.util.Collection;

// This class is for testing the PrimeNumberChecker class.
// It uses parameterized tests to check multiple values in one test.
@RunWith(Parameterized.class)
public class PrimeNumberCheckerTest {

    private int inputNumber;
    private boolean expectedResult;

    // Constructor to initialize with each set of parameters.
    public PrimeNumberCheckerTest(int inputNumber, boolean expectedResult) {
        this.inputNumber = inputNumber;
        this.expectedResult = expectedResult;
    }

    // Parameters for the test. Each array entry here will result in a separate test execution.
    @Parameterized.Parameters
    public static Collection<Object[]> primeNumbers() {
        return Arrays.asList(new Object[][] {
            { 2, true },
            { 6, false },
            { 19, true },
            { 22, false },
            { 23, true }
        });
    }

    // The test method to check if the PrimeNumberChecker class is working as expected.
    @Test
    public void testPrimeNumberChecker() {
        System.out.println("Testing if " + inputNumber + " is prime. Expected result: " + expectedResult);
        // Assert that the result from PrimeNumberChecker matches the expected result.
        assertEquals(expectedResult, PrimeNumberChecker.isPrime(inputNumber));
    }
}
