package question5;

import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.Test;

import java.util.Arrays;
import java.util.Collection;

import static org.junit.Assert.assertEquals;

@RunWith(Parameterized.class)
public class FibonacciTest {

    private int index;
    private int expectedFibonacciNumber;

    // Constructor for parameterized test data
    // This constructor initializes the test data.
    public FibonacciTest(int index, int expectedFibonacciNumber) {
        this.index = index;
        this.expectedFibonacciNumber = expectedFibonacciNumber;
        System.out.println("Initializing test data with index: " + index + " and expected Fibonacci number: " + expectedFibonacciNumber);
    }

    // Static method that generates and returns test data
    // This method provides a collection of Fibonacci numbers for testing.
    @Parameterized.Parameters
    public static Collection<Object[]> data() {
        System.out.println("Generating test data for Fibonacci sequence");
        return Arrays.asList(new Object[][] {
            {0, 0},
            {1, 1},
            {2, 1},
            {3, 2},
            {4, 3},
            {5, 5},
            {6, 8},
            {7, 13},
            {8, 21},
            {9, 34}
        });
    }

    // Test method to check the Fibonacci computation
    // This test will validate if the computed Fibonacci number matches the expected value.
    @Test
    public void testFibonacci() {
        System.out.println("Testing Fibonacci computation for index: " + index);
        assertEquals(expectedFibonacciNumber, Fibonacci.compute(index));
        System.out.println("Test passed for index: " + index);
    }
}
